# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ef3e2d9c96095a09e4606316e02a7fd946a8a8dcb480610c230e3834c2c7cb9faf5dba0126c9462d99f44b23a0236d0ce793b5db24f78597f87a827b2f687788'
